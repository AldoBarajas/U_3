# Guía para GitHub, evidencias reales y YouTube

## GitHub (un repositorio público)
1. En github.com crea un repositorio público, por ejemplo `biblioteca-escolar-unidad3`.
2. Sube todo el contenido de esta carpeta (no hace falta subir ZIP dentro del repositorio).
3. Comprueba que los dos PDFs, el `schema.sql`, los `.drawio` y los diagramas exportados se ven en el repositorio.
4. Copia su URL y pégala como enlace de ambas tareas en Teams.

## Evidencias en PostgreSQL/pgAdmin para Tarea 3.2
1. Crea una base **vacía** para la práctica; no uses base productiva.
2. Ejecuta `SQL/schema.sql` desde Query Tool; captura la ejecución sin errores.
3. Refresca el árbol `Schemas > biblioteca > Tables`; captura las 12 tablas.
4. Abre propiedades/constraints de `prestamo` y de `libro_autor` para mostrar FKs.
5. Ejecuta `SQL/verificacion_esquema.sql`, captura total de tablas, FKs, índices.
6. Ejecuta `SQL/datos_ejemplo.sql` y `SQL/pruebas_integridad.sql`; captura los mensajes `NOTICE: OK` y la consulta final de conteos.
7. Genera el ERD desde pgAdmin u otra herramienta conectada al SGBD y guárdalo como PNG/PDF. Esta evidencia debe sustituir al diagrama documental cuando el profesor exija que provenga del SGBD.
8. Para anexar evidencias al PDF, inserta páginas o capturas en un editor de PDF y guarda versión final. No presentes las cifras esperadas como observadas.

## Video 3.1 (6 a 9 minutos)
- Pantalla: muestra Unidad 2 y el PDF Tarea 3.1. Webcam visible en la esquina inferior derecha.
- 0:00 Introducción: mismo caso biblioteca, objetivo y entidades.
- 1:00 Definir tupla, atributo, dominio, PK y FK con un ejemplo concreto.
- 2:30 Describir 1:1 (ISA Persona-Estudiante/Docente) y 1:N Libro-Ejemplar.
- 4:00 Mostrar N:M Autor-Libro y Libro-Colección convertidas a tablas puente.
- 5:20 Mostrar telefonos como tabla propia y derivados como vistas.
- 6:20 Explicar cardinalidades mínimas, prestamo activo e integridad.
- 7:20 Conclusión e invitación a consultar repositorio.

## Video 3.2 (6 a 10 minutos)
- Captura de pantalla de pgAdmin (o psql) + webcam en esquina inferior derecha.
- Presenta base de pruebas vacía; explica por qué no se emplea DROP en schema.sql.
- Ejecuta schema.sql; confirma creación limpia de 12 tablas.
- Muestra claves PK y FK; distingue CASCADE estructural de RESTRICT histórico.
- Localiza índice único parcial y triggers diferibles.
- Ejecuta verificacion_esquema.sql, datos_ejemplo.sql y pruebas_integridad.sql.
- Muestra ERD **generado por la herramienta conectada a PostgreSQL**, compara con diagrama adjunto.
- Concluye mostrando repositorio y rutas de archivos.

Publica ambos videos en **el mismo canal** y en modo **Público**, verifica sus enlaces y pégalos en Teams. Si usas OBS, combina captura de pantalla con la fuente de webcam encima en la esquina inferior derecha.
